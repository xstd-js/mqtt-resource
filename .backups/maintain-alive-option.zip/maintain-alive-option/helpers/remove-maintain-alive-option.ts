import type { MaintainAliveOption } from '../maintain-alive-option.ts';

export function removeMaintainAliveOption(
  inputs: MaintainAliveOption[],
  item: MaintainAliveOption,
): void {
  const index: number = inputs.indexOf(item);

  if (index === -1) {
    throw new Error(`Cannot remove unknown maintain alive option: ${item}`);
  }

  inputs.splice(index, 1);
}
