import { type MaintainAliveOption } from '../maintain-alive-option.ts';

export function resolveMaintainAliveOption(input: MaintainAliveOption): number {
  return typeof input === 'number' ? input : input();
}
