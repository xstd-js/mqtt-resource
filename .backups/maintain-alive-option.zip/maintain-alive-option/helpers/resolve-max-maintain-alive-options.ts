import { type MaintainAliveOption } from '../maintain-alive-option.ts';
import { resolveMaintainAliveOption } from './resolve-maintain-alive-option.ts';

export function resolveMaxMaintainAliveOptions(inputs: Iterable<MaintainAliveOption>): number {
  let max: number = 0;

  for (const input of inputs) {
    max = Math.max(max, resolveMaintainAliveOption(input));
  }

  return max;
}
