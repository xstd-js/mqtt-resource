export interface MaintainAliveFunction {
  (): number;
}
