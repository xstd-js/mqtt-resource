import { type MaintainAliveFunction } from './maintain-alive-function.ts';

export type MaintainAliveOption = number | MaintainAliveFunction;
