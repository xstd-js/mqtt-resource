import { type MaintainAliveOption } from './maintain-alive-option.ts';

export interface HavingMaintainAliveOption {
  readonly maintainAlive?: MaintainAliveOption;
}
